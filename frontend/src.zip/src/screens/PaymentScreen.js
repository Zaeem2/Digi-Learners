import React, { useState } from "react"
import { Form, Button, Col } from "react-bootstrap"
import { useDispatch, useSelector } from "react-redux"
import FormContainer from "../components2/FormContainer"
import CheckoutSteps from "../components2/CheckoutSteps"
import { savePaymentMethod } from "../actions/cartActions"

const PaymentScreen = ({ history }) => {
  const cart = useSelector((state) => state.cart)
  const { shippingAddress } = cart

  if (!shippingAddress.address) {
    history.push("/shipping")
  }

  const [paymentMethod, setPaymentMethod] = useState("")

  const dispatch = useDispatch()

  const submitHandler = (e) => {
    e.preventDefault()
    dispatch(savePaymentMethod(paymentMethod))
    history.push("/placeorder")
  }

  return (
    <FormContainer>
      <CheckoutSteps step1 step2 step3 />
      <h1>Payment Method</h1>
      <Form onSubmit={submitHandler}>
        <Form.Group>
          <Form.Label as="legend">Select Method</Form.Label>
          <br />
          <Col>
            <Form.Check
              type="radio"
              label=" Credit Card"
              id="CreditCard"
              name="paymentMethod"
              value="CreditCard"
              // checked
              onChange={(e) => setPaymentMethod(e.target.value)}
            ></Form.Check>

            <Form.Check
              type="radio"
              label=" Cash on Delivery"
              id="Cash"
              name="paymentMethod"
              value="Cash"
              // checked
              onChange={(e) => setPaymentMethod(e.target.value)}
            ></Form.Check>
            {/* <Form.Check
              type='radio'
              label='Stripe'
              id='Stripe'
              name='paymentMethod'
              value='Stripe'
              onChange={(e) => setPaymentMethod(e.target.value)}
            ></Form.Check> */}
          </Col>
        </Form.Group>

        <Button
          type="submit"
          variant="primary"
          style={{ backgroundColor: "#1eb2a6" }}
        >
          Continue
        </Button>
      </Form>
    </FormContainer>
  )
}

export default PaymentScreen
